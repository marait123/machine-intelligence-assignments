# This file contains the options that you should modify to solve Question 2

def question2_1():
    #TODO: Choose options that would lead to the desired results 
    return {
        "noise": 0.2,
        "discount_factor": 0.99,
        "living_reward": -1
    }

def question2_2():
    #TODO: Choose options that would lead to the desired results
    return {
        "noise": 0.2,
        "discount_factor": 0.99,
        "living_reward": -1
    }

def question2_3():
    #TODO: Choose options that would lead to the desired results
    return {
        "noise": 0.2,
        "discount_factor": 0.99,
        "living_reward": -1
    }

def question2_4():
    #TODO: Choose options that would lead to the desired results
    return {
        "noise": 0.2,
        "discount_factor": 0.99,
        "living_reward": -1
    }

def question2_5():
    #TODO: Choose options that would lead to the desired results
    return {
        "noise": 0.2,
        "discount_factor": 0.99,
        "living_reward": -1
    }

def question2_6():
    #TODO: Choose options that would lead to the desired results
    return {
        "noise": 0.2,
        "discount_factor": 0.99,
        "living_reward": -1
    }